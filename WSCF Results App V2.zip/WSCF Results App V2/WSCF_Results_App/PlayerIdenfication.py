from util import *
from kivy.uix.label import Label

class PlayerIdentification():
	name 	= ""
	color	= []
	description = ""

	def __str__(self):
		return str(name)

class PlayerIdentificationLabel(Label):
	pass