import time

i_file_results               = []
t_file_results               = []
tournament_name              = ""
tournament_date              = (time.strftime("%m/%d/%Y"))
head_td_name                 = ""
num_players                  = None
num_players_to_date          = None

num_indi_trophy_winners      = 0
num_team_trophy_winners      = 0
indi_trophy_highlight        = []
team_trophy_highlight        = []

player_identification_list   = []