POINT 						= 1
LINE 						= 15* POINT
INCH 						= 72
WIDTH 						= 11 * INCH
HEIGHT 						= 8.5 * INCH

MARGIN_TOP 					= HEIGHT - (1 * INCH)
MARGIN_LEFT 				= .20 * INCH
MARGIN_RIGHT 				= WIDTH - INCH
MARGIN_BOTTOM 				= .5 * INCH

PARTICIPANTS_STR 			= "Participants"
PARTICIPANTS_TO_DATE_STR 	= "Participants in tournaments to date 2013-2014"

IGNORE_TEAM 				= ['Code']
