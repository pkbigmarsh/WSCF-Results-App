from kivy.uix.floatlayout import FloatLayout
from kivy.properties import ObjectProperty

class TrophyColorPicker(FloatLayout):
    done = ObjectProperty(None)
    color_picker = ObjectProperty(None)
